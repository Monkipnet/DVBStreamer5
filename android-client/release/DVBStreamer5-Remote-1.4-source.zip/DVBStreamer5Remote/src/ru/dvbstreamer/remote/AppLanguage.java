package ru.dvbstreamer.remote;
/** Saved values are stable across device locales and settings archives. */
public final class AppLanguage {
 public static final String[] CHOICES={"system","ru","en","de"};
 public static boolean valid(String value){for(String v:CHOICES)if(v.equals(value))return true;return false;}
 public static String resolve(String saved,String system){
  String value="system".equals(saved)||!valid(saved)?system:saved;
  if(value==null)return "en";
  value=value.toLowerCase(java.util.Locale.ROOT).replace('_','-').split("-")[0];
  return "ru".equals(value)||"de".equals(value)?value:"en";
 }
}
