package ru.dvbstreamer.remote;
import java.net.URI;
public final class ServerAddress {
 public static String fromFields(String host, String port, boolean https) {
  host=host.trim();
  try {
   if(host.isEmpty() || host.contains("://") || host.contains("/") || host.contains("@") || host.contains("?") || host.contains("#"))throw new Exception();
   int number=Integer.parseInt(port.trim());if(number<1||number>65535)throw new Exception();
   return normalize(new URI(https?"https":"http",null,host,number,"/",null,null).toASCIIString());
  } catch(Exception e) {throw new IllegalArgumentException("address_fields_error");}
 }
 public static String normalize(String text) {
  String value=text.trim();
  if(!value.contains("://")) value="http://"+value;
  try {
   URI u=new URI(value);
   String scheme=u.getScheme();
   if(!("http".equalsIgnoreCase(scheme)||"https".equalsIgnoreCase(scheme)) || u.getHost()==null || u.getUserInfo()!=null || u.getFragment()!=null || u.getQuery()!=null || u.getPort()>65535 || u.getPort()==0 || (u.getPath()!=null && !u.getPath().isEmpty() && !u.getPath().equals("/"))) throw new Exception();
   return new URI(scheme.toLowerCase(),null,u.getHost(),u.getPort(),"/",null,null).toASCIIString();
  } catch(Exception e) { throw new IllegalArgumentException("address_error"); }
 }
}
