(function () {
  'use strict';
  if (window.__dvbRemoteViewportFix) { window.__dvbRemoteViewportFix(); return; }
  var style = document.createElement('style');
  style.id = 'dvb-remote-viewport-style';
  style.textContent =
    '.system-menu-list{box-sizing:border-box!important;min-width:0!important;max-width:var(--remote-vw,100vw)!important;width:280px!important;overflow:auto!important;overscroll-behavior:contain;transform:none!important;right:auto!important;white-space:normal!important}' +
    '.system-menu-list button,.system-menu-list summary{min-width:0!important;max-width:100%!important;white-space:normal!important;overflow-wrap:break-word;overflow-wrap:anywhere;box-sizing:border-box}' +
    '.system-submenu-list{min-width:0!important;max-width:100%!important}' +
    '.modal,.modal-content{box-sizing:border-box!important;min-width:0!important;max-width:100%!important}' +
    '.modal-content{overflow:auto!important;overscroll-behavior:contain;overflow-wrap:anywhere}' +
    '.modal-content input,.modal-content select,.modal-content textarea{box-sizing:border-box!important;min-width:0!important;max-width:100%!important}' +
    '@media(max-width:600px){.header-left{flex-wrap:wrap!important}.header-monitor{flex-wrap:wrap!important;max-width:100%!important}.header-title-block{max-width:100%!important}.header-title-block .title,.header-title-block .server-name{white-space:normal!important;overflow-wrap:break-word}.header-right{width:100%!important}}' +
    '.modal-actions{flex-wrap:wrap!important}.modal-actions button{white-space:normal!important;max-width:100%!important}' +
    '@media(max-width:600px){.header-left,.header-right{min-width:0!important;max-width:100%!important}.header-right{flex-wrap:wrap!important}.modal-content .form-grid{grid-template-columns:minmax(0,1fr)!important}.modal-content .form-grid>*{grid-column:auto!important;min-width:0!important}}';
  (document.head || document.documentElement).appendChild(style);
  var queued = false;
  function fit() {
    queued = false;
    var vv = window.visualViewport;
    var left = vv ? vv.offsetLeft : 0, top = vv ? vv.offsetTop : 0;
    var width = vv ? vv.width : document.documentElement.clientWidth;
    var height = vv ? vv.height : window.innerHeight;
    var gap = 8;
    document.documentElement.style.setProperty('--remote-vw', Math.max(1, width - gap * 2) + 'px');
    document.querySelectorAll('.system-menu[open] > .system-menu-list').forEach(function (menu) {
      var root = menu.parentElement;
      var summary = root.querySelector('summary');
      if (!summary) return;
      var anchor = summary.getBoundingClientRect();
      var parent = menu.offsetParent;
      var origin = parent ? parent.getBoundingClientRect() : {left:0, top:0};
      var menuWidth = menu.getBoundingClientRect().width;
      var x = Math.max(left + gap, Math.min(anchor.right - menuWidth, left + width - gap - menuWidth));
      var below = Math.max(0, top + height - gap - anchor.bottom - 6);
      var above = Math.max(0, anchor.top - 6 - top - gap);
      var naturalHeight = menu.scrollHeight + 2;
      var goUp = below < Math.min(naturalHeight, 160) && above > below;
      var available = goUp ? above : below;
      var y = goUp ? anchor.top - 6 - Math.min(naturalHeight, available) : anchor.bottom + 6;
      if (available < 64) { y = top + gap; available = Math.max(1, height - gap * 2); }
      menu.style.setProperty('left', (x - origin.left + (parent ? parent.scrollLeft : 0)) + 'px', 'important');
      menu.style.setProperty('top', (y - origin.top + (parent ? parent.scrollTop : 0)) + 'px', 'important');
      menu.style.setProperty('max-height', Math.max(1, available) + 'px', 'important');
    });
    document.querySelectorAll('.modal').forEach(function (modal) {
      if (getComputedStyle(modal).display === 'none') return;
      var rect = modal.getBoundingClientRect();
      // Keep the overlay inside the visual viewport, including above the keyboard.
      var y = Math.max(top + gap, Math.min(rect.top, top + height - gap - Math.min(96, height / 2)));
      modal.style.setProperty('top', y + 'px', 'important');
      modal.style.setProperty('left', (left + gap) + 'px', 'important');
      modal.style.setProperty('right', Math.max(gap, document.documentElement.clientWidth - left - width + gap) + 'px', 'important');
      modal.style.setProperty('bottom', Math.max(0, window.innerHeight - top - height) + 'px', 'important');
      var computed = getComputedStyle(modal);
      var padding = (parseFloat(computed.paddingTop) || 0) + (parseFloat(computed.paddingBottom) || 0);
      var available = Math.max(1, top + height - y - padding - gap);
      modal.querySelectorAll('.modal-content').forEach(function (content) {
        content.style.setProperty('max-height', available + 'px', 'important');
      });
    });
  }
  function schedule() { if (!queued) { queued = true; requestAnimationFrame(fit); } }
  window.__dvbRemoteViewportFix = schedule;
  document.addEventListener('toggle', schedule, true);
  document.addEventListener('click', schedule, true);
  document.addEventListener('focusin', schedule, true);
  window.addEventListener('resize', schedule);
  window.addEventListener('orientationchange', schedule);
  window.addEventListener('scroll', schedule, {passive:true});
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', schedule);
    window.visualViewport.addEventListener('scroll', schedule);
  }
  if (window.ResizeObserver) {
    var sizes = new ResizeObserver(schedule);
    document.querySelectorAll('header,.system-menu > summary').forEach(function (element) { sizes.observe(element); });
  }
  // Only observe visibility changes, not our own style updates or live metrics.
  new MutationObserver(schedule).observe(document.documentElement, {subtree:true, attributes:true, attributeFilter:['open','class','hidden']});
  schedule();
})();
