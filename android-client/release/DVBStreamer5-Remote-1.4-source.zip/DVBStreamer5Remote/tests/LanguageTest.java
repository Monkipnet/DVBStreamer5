package ru.dvbstreamer.remote;
import org.json.*;
public class LanguageTest {
 static int n=0;
 static void eq(Object want,Object got){if(!want.equals(got))throw new AssertionError(want+" != "+got);n++;}
 public static void main(String[] args)throws Exception{
  eq("de",AppLanguage.resolve("system","de-DE"));eq("ru",AppLanguage.resolve("system","ru_RU"));eq("en",AppLanguage.resolve("system","fr"));
  eq("de",AppLanguage.resolve("de","ru"));eq("en",AppLanguage.resolve("en","de"));eq("ru",AppLanguage.resolve("ru","en"));eq("en",AppLanguage.resolve("system",null));eq("de",AppLanguage.resolve("invalid","de"));
  JSONObject settings=new JSONObject().put("servers",new JSONArray()).put("textZoom",125);
  eq("system",SettingsBackup.decode(new JSONObject().put("format",SettingsBackup.FORMAT).put("version",1).put("encrypted",false).put("settings",settings).toString(),null).getString("language"));
  char[] password="localization-test-password".toCharArray();
  for(String language:AppLanguage.CHOICES){settings.put("language",language);eq(language,SettingsBackup.decode(new JSONObject().put("format",SettingsBackup.FORMAT).put("version",1).put("encrypted",false).put("settings",settings).toString(),null).getString("language"));eq(language,SettingsBackup.decode(SettingsBackup.encode(settings,password),password).getString("language"));}
  settings.put("language","not-a-language");boolean rejected=false;try{SettingsBackup.validate(settings);}catch(IllegalArgumentException e){rejected=true;}eq(true,rejected);
  System.out.println("PASS: "+n+" language selection, legacy archive and language round-trip assertions");
 }
}
