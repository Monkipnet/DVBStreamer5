from pathlib import Path
import re,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
resources={}
for folder in ('values','values-ru','values-de'):
 rows=ET.parse(root/'res'/folder/'strings.xml').getroot().findall('string')
 data={row.attrib['name']:row.text for row in rows}
 assert len(data)==len(rows),'Duplicate keys'
 assert all(value and value.strip('"').strip() for value in data.values()),'Empty translation'
 resources[folder]=data
expected=set(resources['values'])
for folder,data in resources.items():assert set(data)==expected,folder
java=(root/'src/ru/dvbstreamer/remote/MainActivity.java').read_text()
assert set(re.findall(r'tr\("([a-z_]+)"\)',java))<=expected
for literal in re.findall(r'"(?:[^"\\]|\\.)*"',java):
 if re.search('[А-Яа-яЁё]',literal):assert literal=='"Русский"',literal
for folder in resources:
 assert resources[folder]['auto_enabled'].endswith(' "')
 assert resources[folder]['http_prefix'].endswith(' "')
print('PASS:',len(expected),'complete strings per locale; all UI references resolve; no hardcoded Russian UI text')
