#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/deps build/test-classes
json_jar="$(pwd)/build/deps/json-20240303.jar"
if [ ! -f "$json_jar" ]; then curl -fL https://repo.maven.apache.org/maven2/org/json/json/20240303/json-20240303.jar -o "$json_jar"; fi
javac --release 8 -cp "$json_jar" -d build/test-classes src/ru/dvbstreamer/remote/AppLanguage.java src/ru/dvbstreamer/remote/ServerAddress.java src/ru/dvbstreamer/remote/SettingsBackup.java src/ru/dvbstreamer/remote/LoginClient.java tests/*.java
python3 scripts/check_translations.py
java -cp "build/test-classes:$json_jar" ru.dvbstreamer.remote.LanguageTest
java -cp "build/test-classes:$json_jar" AddressTest
java -cp "build/test-classes:$json_jar" ru.dvbstreamer.remote.BackupTest
python3 scripts/test_login.py "$json_jar"
