const {chromium}=require('playwright-core');
const path=require('path');
const root=path.resolve(__dirname,'..');
const fs=require('fs');
fs.mkdirSync(path.join(root,'build/viewport'),{recursive:true});
(async()=>{
 const source=fs.readFileSync(process.argv[2],'utf8');
 const html=source.split('R"HTML(')[1].split(')HTML"')[0].replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
 const fix=fs.readFileSync(path.join(root,'assets/viewport-fix.js'),'utf8');
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});let checks=0;
 try{
  for(const [width,height] of [[320,480],[360,640],[640,320],[800,1280],[1280,800]]){
   const page=await browser.newPage({viewport:{width,height}});
   await page.setContent(html,{waitUntil:'domcontentloaded'});
   await page.addScriptTag({content:fix});
   for(const largeText of [false,true]){
    await page.evaluate(big=>{document.documentElement.style.fontSize=big?'21px':'14px';document.querySelectorAll('.system-menu details').forEach(e=>e.open=true);document.querySelector('.system-menu').open=true;},largeText);
    await page.waitForTimeout(80);
    const bounds=await page.evaluate(()=>{let e=document.querySelector('.system-menu-list'),r=e.getBoundingClientRect();return {x:r.x,y:r.y,right:r.right,bottom:r.bottom,w:innerWidth,h:innerHeight,scroll:e.scrollHeight>e.clientHeight};});
    if(bounds.x<7||bounds.y<7||bounds.right>width-7||bounds.bottom>height-7)throw Error(JSON.stringify({width,height,largeText,bounds}));checks++;
    await page.evaluate(()=>{const menu=document.querySelector('.system-menu-list');menu.scrollTop=menu.scrollHeight;});
    const last=await page.evaluate(()=>{const menu=document.querySelector('.system-menu-list'),r=menu.getBoundingClientRect();const items=[...menu.querySelectorAll('button')].filter(e=>e.getClientRects().length);const b=items.at(-1).getBoundingClientRect();return {bottom:b.bottom,limit:r.bottom};});
    if(last.bottom>last.limit+1)throw Error('Bottom item unreachable: '+JSON.stringify(last));checks++;
   }
   await page.screenshot({path:path.join(root,`build/viewport/menu-${width}x${height}.png`)});
   await page.evaluate(()=>{
    document.querySelector('.system-menu').open=false;
    const content=document.querySelector('.modal-content.stream-modal') || document.querySelector('.modal-content');
    const modal=content.closest('.modal');modal.style.display='flex';
    window.__dvbRemoteViewportFix();
   });await page.waitForTimeout(80);
   const modalOk=await page.evaluate(()=>{
    const content=document.querySelector('.modal-content.stream-modal') || document.querySelector('.modal-content');
    const r=content.getBoundingClientRect();return {left:r.left,top:r.top,right:r.right,bottom:r.bottom,w:innerWidth,h:innerHeight};
   });
   if(modalOk.left<0||modalOk.right>width||modalOk.top<0||modalOk.bottom>height)throw Error('Modal bounds failed: '+JSON.stringify(modalOk));checks++;
   await page.evaluate(()=>{document.querySelectorAll('.modal').forEach(m=>m.style.display='none');document.querySelector('.system-menu').open=true;});

   // Resize while open to simulate rotation and reduced keyboard viewport.
   await page.setViewportSize({width:320,height:240});await page.waitForTimeout(80);
   const ok=await page.evaluate(()=>{let r=document.querySelector('.system-menu-list').getBoundingClientRect();return r.left>=7&&r.right<=innerWidth-7&&r.top>=7&&r.bottom<=innerHeight-7;});
   if(!ok)throw Error('Resize bounds failed');checks++;await page.close();
  }
  console.log('PASS: '+checks+' open-menu bounds, expanded submenu scrolling, larger text and resize checks');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1)});
