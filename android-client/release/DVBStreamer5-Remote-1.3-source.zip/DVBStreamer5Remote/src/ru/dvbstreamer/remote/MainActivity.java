package ru.dvbstreamer.remote;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 private final int BG=Color.rgb(15,18,24),PANEL=Color.rgb(19,23,31),FG=Color.rgb(238,238,238),MUTED=Color.rgb(165,180,199),ACCENT=Color.rgb(125,209,255);
 private LinearLayout root,error; private FrameLayout frame;private WebView web;private ProgressBar progress;
 private JSONArray profiles;private SharedPreferences prefs;private final SecureStore secrets=new SecureStore();
 private final ExecutorService io=Executors.newSingleThreadExecutor();
 private ValueCallback<Uri[]> upload;private String server="",pendingExport;private int activeIndex=-1,generation=0;
 private String activeLogin="",activePassword="";private boolean authTried=false;
 @Override protected void attachBaseContext(Context base){
  String choice=base.getSharedPreferences("servers",MODE_PRIVATE).getString("language","system");
  String device=android.content.res.Resources.getSystem().getConfiguration().getLocales().get(0).getLanguage();
  android.content.res.Configuration config=new android.content.res.Configuration(base.getResources().getConfiguration());
  config.setLocales(new LocaleList(new Locale(AppLanguage.resolve(choice,device))));
  super.attachBaseContext(base.createConfigurationContext(config));
 }
 private String tr(String name){int id=getResources().getIdentifier(name,"string",getPackageName());return id==0?name:getString(id);}
 private void chooseLanguage(){
  String saved=prefs.getString("language","system");int selected=0;
  for(int i=0;i<AppLanguage.CHOICES.length;i++)if(AppLanguage.CHOICES[i].equals(saved))selected=i;
  new AlertDialog.Builder(this).setTitle(tr("language")).setSingleChoiceItems(new String[]{tr("language_system"),"Русский","English","Deutsch"},selected,(dialog,which)->{
   String choice=AppLanguage.CHOICES[which];dialog.dismiss();if(choice.equals(saved))return;
   prefs.edit().putString("language",choice).commit();recreate();
  }).setNegativeButton(tr("cancel"),null).show();
 }
 private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,dp(8),0,dp(8));return t;}
 private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 private GradientDrawable background(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(10));d.setStroke(dp(1),Color.rgb(49,63,82));return d;}
 private Button button(String s,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(FG);b.setTextSize(14);b.setBackground(background(Color.rgb(27,37,52)));b.setPadding(dp(12),dp(8),dp(12),dp(8));b.setMinHeight(dp(48));b.setMinimumWidth(0);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);b.setLayoutParams(lp);b.setOnClickListener(l);return b;}
 private EditText input(LinearLayout box,String title,String value,int type){box.addView(text(title,14,MUTED));EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(FG);e.setHintTextColor(MUTED);e.setTextSize(16);e.setInputType(type);e.setText(value);e.setBackground(background(BG));e.setPadding(dp(12),dp(12),dp(12),dp(12));e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);box.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}
 private Spinner selector(LinearLayout parent,int selected){Spinner s=new Spinner(this);ArrayList<String> labels=new ArrayList<>();for(int i=0;i<profiles.length();i++){JSONObject p=profiles.optJSONObject(i);labels.add(p.optString("name")+" · "+Uri.parse(p.optString("url")).getAuthority());}
  ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,labels){
   @Override public View getView(int p,View v,android.view.ViewGroup g){TextView t=(TextView)super.getView(p,v,g);t.setTextColor(ACCENT);t.setTextSize(15);t.setSingleLine(true);t.setEllipsize(android.text.TextUtils.TruncateAt.END);t.setPadding(dp(10),dp(10),dp(4),dp(10));return t;}
   @Override public View getDropDownView(int p,View v,android.view.ViewGroup g){TextView t=(TextView)super.getDropDownView(p,v,g);t.setTextColor(FG);t.setBackgroundColor(PANEL);t.setMaxLines(3);t.setPadding(dp(14),dp(14),dp(14),dp(14));return t;}
  };adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(adapter);s.setBackground(background(PANEL));s.setContentDescription(tr("server_selection"));if(!labels.isEmpty())s.setSelection(Math.max(0,Math.min(selected,labels.size()-1)));parent.addView(s,new LinearLayout.LayoutParams(-1,dp(58)));return s;
 }
 @Override public void onCreate(Bundle state){super.onCreate(state);prefs=getSharedPreferences("servers",MODE_PRIVATE);
  try{profiles=new JSONArray(prefs.getString("profiles","[]"));}catch(Exception e){profiles=new JSONArray();}
  root=column();root.setBackgroundColor(BG);root.setFitsSystemWindows(true);root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets.consumeSystemWindowInsets();});setContentView(root);showProfiles();
 }
 private void dispose(){generation++;activePassword="";activeLogin="";if(web!=null){web.stopLoading();if(web.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)web.getParent()).removeView(web);web.destroy();web=null;}if(upload!=null){upload.onReceiveValue(null);upload=null;}error=null;}
 private void showProfiles(){dispose();activeIndex=-1;root.removeAllViews();ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout page=column();page.setPadding(dp(22),dp(20),dp(22),dp(22));scroll.addView(page);root.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
  LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);ImageView icon=new ImageView(this);icon.setImageResource(getResources().getIdentifier("icon","drawable",getPackageName()));icon.setContentDescription(tr("logo_description"));LinearLayout.LayoutParams logo=new LinearLayout.LayoutParams(dp(54),dp(54));logo.rightMargin=dp(12);brand.addView(icon,logo);TextView title=text("DVBStreamer5",27,FG);title.setTypeface(null,Typeface.BOLD);brand.addView(title);page.addView(brand);page.addView(text(tr("subtitle"),15,MUTED));
  page.addView(text(tr("choose_server"),12,ACCENT));
  if(profiles.length()>0){Spinner choose=selector(page,prefs.getInt("selected",0));TextView info=text("",14,MUTED);page.addView(info);
   choose.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){prefs.edit().putInt("selected",pos).apply();JSONObject item=profiles.optJSONObject(pos);info.setText(item.optBoolean("autoLogin")?tr("auto_enabled")+item.optString("login"):tr("panel_login"));}});
   page.addView(button(tr("connect"),v->connect(choose.getSelectedItemPosition())));page.addView(button(tr("edit_server"),v->editProfile(choose.getSelectedItemPosition())));
  }else page.addView(text(tr("no_servers"),16,MUTED));
  page.addView(button(tr("add_server_button"),v->editProfile(-1)));page.addView(text(tr("app_settings"),12,ACCENT));page.addView(button(tr("language"),v->chooseLanguage()));page.addView(text(tr("language_note"),13,MUTED));page.addView(button(tr("export_settings"),v->exportChoice()));page.addView(button(tr("import_settings"),v->openImport()));
  page.addView(text(tr("network_hint"),14,MUTED));
  page.addView(button(tr("about"),v->new AlertDialog.Builder(this).setTitle("DVBStreamer5 Remote · 1.3").setMessage(tr("about_details")).setPositiveButton(tr("close"),null).show()));
 }
 private void editProfile(int index){JSONObject p=index<0?new JSONObject():profiles.optJSONObject(index);LinearLayout fields=column();fields.setPadding(dp(20),dp(6),dp(20),dp(12));ScrollView scroll=new ScrollView(this);scroll.addView(fields);
  EditText name=input(fields,tr("name"),p.optString("name"),1);Uri uri=Uri.parse(p.optString("url","http://192.168.1.10:9000/"));
  Spinner protocol=new Spinner(this);ArrayAdapter<String> protocols=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"HTTP","HTTPS"});protocol.setAdapter(protocols);protocol.setSelection("https".equals(uri.getScheme())?1:0);fields.addView(text(tr("protocol"),14,MUTED));fields.addView(protocol);
  EditText host=input(fields,tr("host"),index<0?"":uri.getHost(),android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);host.setHint("192.168.1.10");
  EditText port=input(fields,tr("port"),String.valueOf(uri.getPort()==-1?("https".equals(uri.getScheme())?443:80):uri.getPort()),android.text.InputType.TYPE_CLASS_NUMBER);if(index<0)port.setText("9000");
  fields.addView(text(tr("port_hint"),12,MUTED));
  EditText login=input(fields,tr("username"),p.optString("login"),android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);EditText pass=input(fields,tr("password"), "",129);pass.setHint(p.optString("secret").isEmpty()?tr("server_password"):tr("password_saved"));
  CheckBox auto=new CheckBox(this);auto.setText(tr("save_auto_login"));auto.setTextColor(FG);auto.setChecked(p.optBoolean("autoLogin",false));fields.addView(auto);fields.addView(text(tr("auto_login_hint"),12,MUTED));
  AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle(index<0?tr("add_server"):tr("server_settings")).setView(scroll).setPositiveButton(tr("save"),null).setNegativeButton(tr("cancel"),null);
  if(index>=0)builder.setNeutralButton(tr("delete"),(d,w)->new AlertDialog.Builder(this).setMessage(tr("delete_profile")).setPositiveButton(tr("delete"),(dd,ww)->{profiles.remove(index);saveProfiles();showProfiles();}).setNegativeButton(tr("cancel"),null).show());
  AlertDialog dialog=builder.create();dialog.setOnShowListener(d->dialog.getButton(-1).setOnClickListener(v->{try{
   String address=ServerAddress.fromFields(host.getText().toString(),port.getText().toString(),protocol.getSelectedItemPosition()==1);String label=name.getText().toString().trim();if(label.isEmpty())label=Uri.parse(address).getHost();if(label.length()>120)throw new IllegalArgumentException(tr("name_too_long"));
   String user=login.getText().toString(),password=pass.getText().toString();if(user.length()>256||password.length()>4096)throw new IllegalArgumentException(tr("credentials_too_long"));
   String encrypted="";if(auto.isChecked()){if(user.trim().isEmpty())throw new IllegalArgumentException(tr("username_required"));if(password.isEmpty()){if(p.optString("secret").isEmpty())throw new IllegalArgumentException(tr("password_required"));secrets.decrypt(p.getString("secret"));encrypted=p.getString("secret");}else encrypted=secrets.encrypt(password);}
   JSONObject item=new JSONObject().put("name",label).put("url",address).put("login",user).put("autoLogin",auto.isChecked()).put("secret",encrypted);
   if(index<0){if(profiles.length()>=100)throw new IllegalArgumentException(tr("server_limit"));profiles.put(item);prefs.edit().putInt("selected",profiles.length()-1).apply();}else profiles.put(index,item);
   saveProfiles();pass.setText("");dialog.dismiss();showProfiles();
  }catch(Exception ex){showMessage(tr("save_failed"),ex instanceof IllegalArgumentException?tr(ex.getMessage()):tr("secret_read_failed"));}}));dialog.show();
 }
 private void saveProfiles(){prefs.edit().putString("profiles",profiles.toString()).apply();}
 private void showMessage(String title,String message){if(!isFinishing()&&!isDestroyed())new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton(tr("ok"),null).show();}
 private boolean sameOrigin(Uri u){Uri s=Uri.parse(server);int up=u.getPort()==-1?("https".equals(u.getScheme())?443:80):u.getPort(),sp=s.getPort()==-1?("https".equals(s.getScheme())?443:80):s.getPort();return s.getScheme().equalsIgnoreCase(u.getScheme())&&s.getHost().equalsIgnoreCase(u.getHost()==null?"":u.getHost())&&up==sp;}
 private void external(Uri u){if(!"https".equals(u.getScheme())&&!"http".equals(u.getScheme())){showMessage(tr("download"),tr("unsupported_link"));return;}new AlertDialog.Builder(this).setMessage(tr("open_browser_question")+u).setPositiveButton(tr("open"),(d,w)->{try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){showMessage(tr("browser"),tr("browser_missing"));}}).setNegativeButton(tr("cancel"),null).show();}
 private void connect(int index){if(index<0||index>=profiles.length())return;dispose();activeIndex=index;JSONObject profile=profiles.optJSONObject(index);server=profile.optString("url");prefs.edit().putInt("selected",index).apply();root.removeAllViews();authTried=false;
  LinearLayout toolbar=new LinearLayout(this);toolbar.setGravity(Gravity.CENTER_VERTICAL);toolbar.setBackgroundColor(PANEL);toolbar.setPadding(dp(6),dp(4),dp(6),dp(4));Button back=button("‹",v->leave());back.setContentDescription(tr("server_list"));toolbar.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));
  LinearLayout holder=column();Spinner choose=selector(holder,index);LinearLayout.LayoutParams choiceLP=new LinearLayout.LayoutParams(0,-2,1);choiceLP.leftMargin=dp(6);choiceLP.rightMargin=dp(6);toolbar.addView(holder,choiceLP);
  choose.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){if(pos==activeIndex)return;new AlertDialog.Builder(MainActivity.this).setMessage(tr("switch_prefix")+profiles.optJSONObject(pos).optString("name")+tr("switch_suffix")).setPositiveButton(tr("switch_action"),(d,w)->connect(pos)).setNegativeButton(tr("cancel"),(d,w)->choose.setSelection(activeIndex)).setOnCancelListener(d->choose.setSelection(activeIndex)).show();}});
  Button menu=button("⋮",v->showMenu(v));menu.setContentDescription(tr("connection_menu"));toolbar.addView(menu,new LinearLayout.LayoutParams(dp(48),dp(48)));root.addView(toolbar);
  progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));root.addView(progress,new LinearLayout.LayoutParams(-1,dp(3)));frame=new FrameLayout(this);root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));
  web=new WebView(this);web.setBackgroundColor(BG);frame.addView(web,new FrameLayout.LayoutParams(-1,-1));WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setSupportZoom(true);settings.setBuiltInZoomControls(true);settings.setDisplayZoomControls(false);settings.setUseWideViewPort(true);settings.setLoadWithOverviewMode(true);settings.setTextZoom(prefs.getInt("textZoom",100));settings.setMediaPlaybackRequiresUserGesture(true);settings.setSaveFormData(false);CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){if(sameOrigin(r.getUrl()))return false;external(r.getUrl());return true;}
   @Override public void onPageStarted(WebView v,String u,android.graphics.Bitmap icon){hideError();progress.setVisibility(View.VISIBLE);}
   @Override public void onPageFinished(WebView v,String u){progress.setVisibility(View.GONE);CookieManager.getInstance().flush();}
   @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())showError(tr("connection_check")+e.getDescription());}
   @Override public void onReceivedHttpError(WebView v,WebResourceRequest r,WebResourceResponse response){if(r.isForMainFrame()&&response.getStatusCode()>=400&&response.getStatusCode()!=401)showError(tr("http_prefix")+response.getStatusCode()+tr("http_suffix"));}
   @Override public void onReceivedSslError(WebView v,SslErrorHandler h,SslError e){h.cancel();showError(tr("tls_error"));}
   @Override public void onReceivedHttpAuthRequest(WebView v,HttpAuthHandler h,String host,String realm){if(!host.equalsIgnoreCase(Uri.parse(server).getHost())||!sameOrigin(Uri.parse(v.getUrl()==null?server:v.getUrl()))){h.cancel();return;}if(!authTried&&!activePassword.isEmpty()){authTried=true;h.proceed(activeLogin,activePassword);return;}manualAuth(h,host);}
  });
  web.setWebChromeClient(new WebChromeClient(){@Override public void onProgressChanged(WebView v,int n){progress.setProgress(n);}@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(upload!=null)upload.onReceiveValue(null);upload=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");try{startActivityForResult(i,10);}catch(Exception e){upload.onReceiveValue(null);upload=null;}return true;}});
  web.setDownloadListener((u,a,b,c,n)->external(Uri.parse(u)));beginLogin(profile);
 }
 private void manualAuth(HttpAuthHandler h,String host){LinearLayout fields=column();fields.setPadding(dp(20),dp(6),dp(20),dp(12));EditText user=input(fields,tr("username"),profiles.optJSONObject(activeIndex).optString("login"),1),pass=input(fields,tr("password"),"",129);new AlertDialog.Builder(this).setTitle(tr("login_prefix")+host).setView(fields).setPositiveButton(tr("sign_in"),(d,w)->{h.proceed(user.getText().toString(),pass.getText().toString());pass.setText("");}).setNegativeButton(tr("cancel"),(d,w)->{h.cancel();showError(tr("login_cancelled_retry"));}).setOnCancelListener(d->{h.cancel();showError(tr("login_cancelled"));}).show();}
 private void beginLogin(JSONObject profile){hideError();if(!profile.optBoolean("autoLogin")){web.loadUrl(server);return;}
  try{activeLogin=profile.getString("login");activePassword=secrets.decrypt(profile.getString("secret"));}catch(Exception e){showError(tr("saved_password_error"));return;}
  final int token=generation;final String target=server,user=activeLogin,password=activePassword;progress.setIndeterminate(true);io.execute(()->{try{LoginClient.Result r=LoginClient.login(target,user,password);runOnUiThread(()->{if(token!=generation||web==null)return;progress.setIndeterminate(false);if(r.status==200){installCookies(r.cookies,0,token,target);}else if(r.status==404||r.status==405){web.loadUrl(target);}else if(r.status==401||r.status==403){authTried=true;showError(tr("auto_rejected"));}else showError(tr("auto_http_prefix")+r.status);});}catch(Exception e){runOnUiThread(()->{if(token!=generation||web==null)return;progress.setIndeterminate(false);showError(tr("auto_failed"));});}});
 }
 private void installCookies(java.util.List<String> cookies,int position,int token,String target){
  if(token!=generation||web==null)return;
  if(position>=cookies.size()){CookieManager.getInstance().flush();web.loadUrl(target);return;}
  CookieManager.getInstance().setCookie(target,cookies.get(position),ok->installCookies(cookies,position+1,token,target));
 }
 private void hideError(){if(error!=null&&frame!=null){frame.removeView(error);error=null;}}
 private void showError(String message){if(isFinishing()||web==null)return;hideError();progress.setIndeterminate(false);progress.setVisibility(View.GONE);error=column();error.setGravity(Gravity.CENTER);error.setPadding(dp(22),dp(16),dp(22),dp(16));error.setBackgroundColor(BG);error.addView(text(tr("connection_failed"),22,FG));error.addView(text(message,16,MUTED));error.addView(button(tr("retry"),v->beginLogin(profiles.optJSONObject(activeIndex))));error.addView(button(tr("server_settings"),v->{int i=activeIndex;showProfiles();editProfile(i);}));error.addView(button(tr("server_list"),v->showProfiles()));frame.addView(error,new FrameLayout.LayoutParams(-1,-1));}
 private void showMenu(View anchor){PopupMenu menu=new PopupMenu(this,anchor);for(String item:new String[]{tr("refresh"),tr("connection_settings"),tr("text_size"),tr("clear_sessions"),tr("change_server")})menu.getMenu().add(item);menu.setOnMenuItemClickListener(i->{String t=i.getTitle().toString();if(t.equals(tr("refresh"))){hideError();web.reload();}else if(t.equals(tr("connection_settings"))){new AlertDialog.Builder(this).setMessage(tr("edit_connection_question")).setPositiveButton(tr("continue_action"),(d,w)->{int n=activeIndex;showProfiles();editProfile(n);}).setNegativeButton(tr("cancel"),null).show();}else if(t.equals(tr("text_size"))){new AlertDialog.Builder(this).setTitle(tr("panel_text_size")).setItems(new String[]{"80%","100%","125%","150%"},(d,w)->{int zoom=new int[]{80,100,125,150}[w];prefs.edit().putInt("textZoom",zoom).apply();web.getSettings().setTextZoom(zoom);}).show();}else if(t.equals(tr("clear_sessions"))){new AlertDialog.Builder(this).setMessage(tr("clear_sessions_question")).setPositiveButton(tr("delete"),(d,w)->{dispose();CookieManager.getInstance().removeAllCookies(ok->{CookieManager.getInstance().flush();WebStorage.getInstance().deleteAllData();showProfiles();});}).setNegativeButton(tr("cancel"),null).show();}else leave();return true;});menu.show();}
 private void leave(){new AlertDialog.Builder(this).setMessage(tr("leave_question")).setPositiveButton(tr("return_action"),(d,w)->showProfiles()).setNegativeButton(tr("stay"),null).show();}
 private JSONObject portableSettings(boolean withPasswords) throws Exception {
  JSONArray servers=new JSONArray();for(int i=0;i<profiles.length();i++){JSONObject p=profiles.getJSONObject(i);JSONObject item=new JSONObject().put("name",p.getString("name")).put("url",p.getString("url")).put("login",p.optString("login")).put("autoLogin",withPasswords&&p.optBoolean("autoLogin"));item.put("password",withPasswords?secrets.decrypt(p.optString("secret")):"");servers.put(item);}
  return new JSONObject().put("servers",servers).put("textZoom",prefs.getInt("textZoom",100)).put("language",prefs.getString("language","system"));
 }
 private void exportChoice(){new AlertDialog.Builder(this).setTitle(tr("export_app_settings")).setItems(new String[]{tr("export_plain"),tr("export_encrypted")},(d,w)->{if(w==0)prepareExport(null);else askArchivePassword(true,null);}).setNegativeButton(tr("cancel"),null).show();}
 private void askArchivePassword(boolean exporting,String archive){LinearLayout fields=column();fields.setPadding(dp(20),0,dp(20),dp(12));fields.addView(text(exporting?tr("archive_password_hint"):tr("archive_password_prompt"),14,MUTED));EditText pass=input(fields,tr("archive_password"),"",129);EditText again=exporting?input(fields,tr("repeat_password"),"",129):null;
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle(exporting?tr("protect_export"):tr("decrypt_archive")).setView(fields).setPositiveButton(exporting?tr("export_action"):tr("open"),null).setNegativeButton(tr("cancel"),null).create();dialog.setOnShowListener(d->dialog.getButton(-1).setOnClickListener(v->{String value=pass.getText().toString();if(exporting&&(value.length()<8||!value.equals(again.getText().toString()))){pass.setError(tr("password_match_error"));return;}char[] password=value.toCharArray();pass.setText("");if(again!=null)again.setText("");dialog.dismiss();if(exporting)prepareExport(password);else decodeImport(archive,password);}));dialog.show();
 }
 private void prepareExport(char[] password){try{final JSONObject snapshot=portableSettings(password!=null);Toast.makeText(this,tr("preparing_archive"),Toast.LENGTH_SHORT).show();io.execute(()->{try{String content=SettingsBackup.encode(snapshot,password);runOnUiThread(()->{if(isFinishing()||isDestroyed())return;pendingExport=content;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");intent.putExtra(Intent.EXTRA_TITLE,password==null?"DVBStreamer5-Remote-settings.json":"DVBStreamer5-Remote-encrypted.json");try{startActivityForResult(intent,20);}catch(Exception e){pendingExport=null;showMessage(tr("export_title"),tr("file_picker_error"));}});}catch(Exception e){runOnUiThread(()->showMessage(tr("export_title"),tr("archive_create_error")));}finally{if(password!=null)Arrays.fill(password,'\0');}});}catch(Exception e){if(password!=null)Arrays.fill(password,'\0');showMessage(tr("export_title"),tr("secret_export_error"));}}
 private void openImport(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");try{startActivityForResult(i,21);}catch(Exception e){showMessage(tr("import_title"),tr("file_picker_error"));}}
 private void readImport(Uri uri){io.execute(()->{try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){if(in==null)throw new IOException();byte[] buffer=new byte[8192];int n,total=0;while((n=in.read(buffer))!=-1){total+=n;if(total>SettingsBackup.MAX_BYTES)throw new IllegalArgumentException(tr("archive_size_limit"));out.write(buffer,0,n);}String archive=new String(out.toByteArray(),StandardCharsets.UTF_8);boolean encrypted=SettingsBackup.isEncrypted(archive);runOnUiThread(()->{if(isFinishing()||isDestroyed())return;if(encrypted)askArchivePassword(false,archive);else decodeImport(archive,null);});}catch(Exception e){runOnUiThread(()->showMessage(tr("import_title"),tr("archive_read_error")));}});}
 private void decodeImport(String archive,char[] password){Toast.makeText(this,tr("checking_archive"),Toast.LENGTH_SHORT).show();io.execute(()->{try{JSONObject decoded=SettingsBackup.decode(archive,password);runOnUiThread(()->confirmImport(decoded));}catch(Exception e){runOnUiThread(()->showMessage(tr("import_title"),password!=null?tr("encrypted_import_error"):tr("plain_import_error")));}finally{if(password!=null)Arrays.fill(password,'\0');}});}
 private void confirmImport(JSONObject decoded){if(isFinishing()||isDestroyed())return;JSONArray list=decoded.optJSONArray("servers");StringBuilder preview=new StringBuilder(tr("archive_server_count")).append(list.length()).append("\n");for(int i=0;i<Math.min(5,list.length());i++){JSONObject p=list.optJSONObject(i);preview.append("\n").append(p.optString("name")).append("\n").append(p.optString("url"));}if(list.length()>5)preview.append("\n…");preview.append(tr("import_replace_hint"));
  new AlertDialog.Builder(this).setTitle(tr("import_question")).setMessage(preview.toString()).setPositiveButton(tr("replace"),(d,w)->applyImport(decoded)).setNegativeButton(tr("cancel"),null).show();
 }
 private void applyImport(JSONObject decoded){io.execute(()->{try{JSONArray next=new JSONArray(),list=decoded.getJSONArray("servers");for(int i=0;i<list.length();i++){JSONObject p=list.getJSONObject(i);String password=p.optString("password");next.put(new JSONObject().put("name",p.getString("name")).put("url",p.getString("url")).put("login",p.optString("login")).put("autoLogin",p.optBoolean("autoLogin")).put("secret",password.isEmpty()?"":secrets.encrypt(password)));}
   runOnUiThread(()->{if(isFinishing()||isDestroyed())return;if(!prefs.edit().putString("profiles",next.toString()).putInt("textZoom",decoded.optInt("textZoom",100)).putInt("selected",0).putString("language",decoded.optString("language","system")).commit()){showMessage(tr("import_title"),tr("settings_write_error"));return;}profiles=next;CookieManager.getInstance().removeAllCookies(ok->{CookieManager.getInstance().flush();WebStorage.getInstance().deleteAllData();recreate();});});
  }catch(Exception e){runOnUiThread(()->showMessage(tr("import_title"),tr("secret_import_error")));}});
 }
 @Override public void onBackPressed(){if(web!=null){if(web.canGoBack()&&error==null)web.goBack();else leave();}else super.onBackPressed();}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
  if(request==10&&upload!=null){upload.onReceiveValue(result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null);upload=null;return;}
  if(request==20){String content=pendingExport;pendingExport=null;if(result==RESULT_OK&&data!=null&&data.getData()!=null){if(content==null){showMessage(tr("export_title"),tr("export_restarted"));return;}Uri uri=data.getData();io.execute(()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException();out.write(content.getBytes(StandardCharsets.UTF_8));out.flush();runOnUiThread(()->Toast.makeText(this,tr("export_success"),Toast.LENGTH_SHORT).show());}catch(Exception e){runOnUiThread(()->showMessage(tr("export_title"),tr("file_write_error")));}});}return;}
  if(request==21&&result==RESULT_OK&&data!=null&&data.getData()!=null)readImport(data.getData());
 }
 @Override protected void onPause(){if(web!=null){web.onPause();CookieManager.getInstance().flush();}super.onPause();}
 @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();}
 @Override protected void onDestroy(){dispose();io.shutdownNow();pendingExport=null;super.onDestroy();}
}
