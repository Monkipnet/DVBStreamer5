package ru.dvbstreamer.remote;
import org.json.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;

/** Portable settings archive. Device-specific encrypted blobs are never exported. */
public final class SettingsBackup {
 public static final String FORMAT="dvbstreamer5-remote-backup";
 public static final int ITERATIONS=210000, MAX_BYTES=2*1024*1024;
 private static final byte[] AAD=(FORMAT+":1").getBytes(StandardCharsets.UTF_8);
 private static SecretKeySpec derive(char[] password,byte[] salt) throws Exception {
  PBEKeySpec spec=new PBEKeySpec(password,salt,ITERATIONS,256);
  byte[] bytes=null;try{bytes=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();return new SecretKeySpec(bytes,"AES");}finally{spec.clearPassword();if(bytes!=null)Arrays.fill(bytes,(byte)0);}
 }
 private static JSONObject envelope(boolean encrypted) throws Exception {return new JSONObject().put("format",FORMAT).put("version",1).put("encrypted",encrypted);}
 public static String encode(JSONObject payload,char[] password) throws Exception {
  JSONObject valid=validate(payload);
  if(password==null){
   JSONArray list=valid.getJSONArray("servers");for(int i=0;i<list.length();i++)list.getJSONObject(i).put("password","").put("autoLogin",false);
   return envelope(false).put("settings",valid).toString(2);
  }
  if(password.length<8)throw new IllegalArgumentException("Пароль архива должен содержать минимум 8 символов.");
  byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);
  Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,derive(password,salt));c.updateAAD(AAD);
  return envelope(true).put("kdf","PBKDF2WithHmacSHA256").put("iterations",ITERATIONS).put("salt",Base64.getEncoder().encodeToString(salt)).put("iv",Base64.getEncoder().encodeToString(c.getIV())).put("ciphertext",Base64.getEncoder().encodeToString(c.doFinal(valid.toString().getBytes(StandardCharsets.UTF_8)))).toString(2);
 }
 public static boolean isEncrypted(String archive) throws Exception {return parse(archive).getBoolean("encrypted");}
 private static JSONObject parse(String archive) throws Exception {
  if(archive.getBytes(StandardCharsets.UTF_8).length>MAX_BYTES)throw new IllegalArgumentException("Файл слишком большой (максимум 2 МБ).");
  JSONObject obj=new JSONObject(archive);
  if(!FORMAT.equals(obj.optString("format"))||obj.optInt("version")!=1||!(obj.opt("encrypted") instanceof Boolean))throw new IllegalArgumentException("Это не поддерживаемый архив настроек DVBStreamer5 Remote.");
  return obj;
 }
 public static JSONObject decode(String archive,char[] password) throws Exception {
  JSONObject obj=parse(archive);
  if(!obj.getBoolean("encrypted"))return validate(obj.getJSONObject("settings"));
  if(password==null||password.length==0)throw new IllegalArgumentException("Введите пароль архива.");
  if(obj.getInt("iterations")!=ITERATIONS||!"PBKDF2WithHmacSHA256".equals(obj.getString("kdf")))throw new IllegalArgumentException("Неподдерживаемое шифрование архива.");
  byte[] salt=Base64.getDecoder().decode(obj.getString("salt")),iv=Base64.getDecoder().decode(obj.getString("iv"));
  if(salt.length!=16||iv.length!=12)throw new IllegalArgumentException("Архив повреждён.");
  Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,derive(password,salt),new GCMParameterSpec(128,iv));c.updateAAD(AAD);
  byte[] clear=c.doFinal(Base64.getDecoder().decode(obj.getString("ciphertext")));
  try{return validate(new JSONObject(new String(clear,StandardCharsets.UTF_8)));}finally{Arrays.fill(clear,(byte)0);}
 }
 public static JSONObject validate(JSONObject settings) throws Exception {
  JSONArray source=settings.getJSONArray("servers"),result=new JSONArray();
  if(source.length()>100)throw new IllegalArgumentException("В архиве больше 100 серверов.");
  int zoom=settings.optInt("textZoom",100);if(zoom!=80&&zoom!=100&&zoom!=125&&zoom!=150)throw new IllegalArgumentException("Недопустимый масштаб текста.");
  for(int i=0;i<source.length();i++){
   JSONObject p=source.getJSONObject(i);String url=ServerAddress.normalize(p.getString("url"));
   String name=p.getString("name").trim(),login=p.optString("login",""),password=p.optString("password","");
   if(name.isEmpty()||name.length()>120||login.length()>256||password.length()>4096)throw new IllegalArgumentException("Недопустимые поля сервера №"+(i+1));
   boolean auto=p.optBoolean("autoLogin",false);
   if(auto&&(login.isEmpty()||password.isEmpty()))throw new IllegalArgumentException("Нет учётных данных автологина у сервера №"+(i+1));
   result.put(new JSONObject().put("name",name).put("url",url).put("login",login).put("autoLogin",auto).put("password",password));
  }
  return new JSONObject().put("servers",result).put("textZoom",zoom);
 }
}
