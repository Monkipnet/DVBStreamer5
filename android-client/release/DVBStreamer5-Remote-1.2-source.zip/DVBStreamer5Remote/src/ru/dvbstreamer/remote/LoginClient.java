package ru.dvbstreamer.remote;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.JSONObject;

final class LoginClient {
 static final class Result {
  int status;List<String> cookies=new ArrayList<>();
 }
 static Result login(String server,String user,String password) throws Exception {
  URL endpoint=new URL(new URL(ServerAddress.normalize(server)),"/api/panel/login");
  HttpURLConnection c=(HttpURLConnection)endpoint.openConnection();
  try {
   c.setConnectTimeout(10000);c.setReadTimeout(10000);c.setInstanceFollowRedirects(false);
   c.setRequestMethod("POST");c.setRequestProperty("Content-Type","application/json; charset=utf-8");c.setRequestProperty("Accept","application/json");c.setDoOutput(true);
   byte[] data=new JSONObject().put("login",user).put("password",password).toString().getBytes(StandardCharsets.UTF_8);
   c.setFixedLengthStreamingMode(data.length);
   try(OutputStream out=c.getOutputStream()){out.write(data);}finally{Arrays.fill(data,(byte)0);}
   Result result=new Result();result.status=c.getResponseCode();
   for(Map.Entry<String,List<String>> header:c.getHeaderFields().entrySet())if("Set-Cookie".equalsIgnoreCase(header.getKey()))result.cookies.addAll(header.getValue());
   return result;
  }finally{c.disconnect();}
 }
}
