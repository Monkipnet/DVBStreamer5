import http.server,json,threading,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
class H(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_POST(self):
  assert self.path=='/api/panel/login'
  assert self.headers['Content-Type']=='application/json; charset=utf-8'
  body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
  if body['login']=='redirect':
   self.send_response(302);self.send_header('Location','http://127.0.0.1:1/credentials-must-not-be-forwarded')
  elif body['login']=='old-server':self.send_response(404)
  elif body=={'login':'operator','password':'test-password'}:
   self.send_response(200);self.send_header('Set-Cookie','dvbstreamer5_panel_session=test; Path=/; HttpOnly');self.send_header('Set-Cookie','dvbstreamer5_panel_logged_out=; Path=/; Max-Age=0')
  else:self.send_response(401)
  self.end_headers();self.wfile.write(b'{}')
server=http.server.HTTPServer(('127.0.0.1',0),H)
threading.Thread(target=server.serve_forever,daemon=True).start()
try:subprocess.run(['java','-cp',str(root/'build/test-classes')+':'+str(Path(sys.argv[1]).resolve()),'ru.dvbstreamer.remote.LoginTest',str(server.server_port)],check=True)
finally:server.shutdown()
