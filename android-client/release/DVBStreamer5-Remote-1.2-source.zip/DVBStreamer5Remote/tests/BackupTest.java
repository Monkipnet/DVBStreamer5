package ru.dvbstreamer.remote;
import org.json.*;
public class BackupTest {
 interface Check {void run()throws Exception;}
 static int count=0;
 static void ok(boolean c){if(!c)throw new AssertionError();count++;}
 static void rejects(Check r)throws Exception{boolean failed=false;try{r.run();}catch(Exception e){failed=true;}ok(failed);}
 public static void main(String[] args)throws Exception{
  JSONObject profile=new JSONObject().put("name","Спутник").put("url","https://server.local:9000").put("login","оператор").put("password","secret-тест-123").put("autoLogin",true);
  JSONObject settings=new JSONObject().put("servers",new JSONArray().put(profile)).put("textZoom",125);
  char[] key="archive-test-2026".toCharArray();String encrypted=SettingsBackup.encode(settings,key);
  ok(SettingsBackup.isEncrypted(encrypted));ok(!encrypted.contains("secret-тест"));ok(!encrypted.contains("server.local"));
  JSONObject result=SettingsBackup.decode(encrypted,key);JSONObject p=result.getJSONArray("servers").getJSONObject(0);
  ok(p.getString("password").equals("secret-тест-123"));ok(p.getString("url").equals("https://server.local:9000/"));ok(p.getBoolean("autoLogin"));ok(result.getInt("textZoom")==125);
  rejects(()->SettingsBackup.decode(encrypted,"wrong-password".toCharArray()));
  JSONObject tampered=new JSONObject(encrypted);String cipher=tampered.getString("ciphertext");tampered.put("ciphertext",(cipher.charAt(0)=='A'?"B":"A")+cipher.substring(1));rejects(()->SettingsBackup.decode(tampered.toString(),key));
  String plain=SettingsBackup.encode(settings,null);ok(!plain.contains("secret-тест"));JSONObject clear=SettingsBackup.decode(plain,null).getJSONArray("servers").getJSONObject(0);ok(!clear.getBoolean("autoLogin"));ok(clear.getString("password").isEmpty());
  rejects(()->SettingsBackup.encode(settings,"short".toCharArray()));rejects(()->SettingsBackup.decode(new JSONObject(plain).put("version",99).toString(),null));
  JSONObject invalid=new JSONObject(settings.toString());invalid.getJSONArray("servers").getJSONObject(0).put("url","javascript:alert(1)");final JSONObject invalidUrl=invalid;rejects(()->SettingsBackup.validate(invalidUrl));
  invalid=new JSONObject(settings.toString());invalid.getJSONArray("servers").getJSONObject(0).put("url","http://user:password@server");final JSONObject invalidUser=invalid;rejects(()->SettingsBackup.validate(invalidUser));
  JSONObject noCreds=new JSONObject(settings.toString());noCreds.getJSONArray("servers").getJSONObject(0).put("password","");rejects(()->SettingsBackup.validate(noCreds));
  JSONObject wrongZoom=new JSONObject(settings.toString()).put("textZoom",500);rejects(()->SettingsBackup.validate(wrongZoom));
  rejects(()->SettingsBackup.decode("{}",null));
  ok(ServerAddress.fromFields("192.168.1.10","9000",false).equals("http://192.168.1.10:9000/"));ok(ServerAddress.fromFields("2001:db8::1","443",true).equals("https://[2001:db8::1]:443/"));
  rejects(()->ServerAddress.fromFields("server","65536",false));rejects(()->ServerAddress.fromFields("server","0",false));rejects(()->ServerAddress.fromFields("server","abc",false));rejects(()->ServerAddress.fromFields("http://server","9000",false));
  System.out.println("PASS: "+count+" archive, encryption and port assertions");
 }
}
