package ru.dvbstreamer.remote;
public class LoginTest {
 public static void main(String[] args)throws Exception {
  String base="http://127.0.0.1:"+args[0]+"/";
  LoginClient.Result ok=LoginClient.login(base,"operator","test-password");
  if(ok.status!=200||ok.cookies.size()!=2)throw new AssertionError("login/cookies");
  LoginClient.Result bad=LoginClient.login(base,"operator","bad");if(bad.status!=401)throw new AssertionError("wrong password");
  LoginClient.Result redirect=LoginClient.login(base,"redirect","test-password");if(redirect.status!=302)throw new AssertionError("redirect must not be followed");
  LoginClient.Result old=LoginClient.login(base,"old-server","test-password");if(old.status!=404)throw new AssertionError("old-server fallback");
  System.out.println("PASS: login POST, two session cookies, rejected credentials, redirect blocked, old-server fallback");
 }
}
