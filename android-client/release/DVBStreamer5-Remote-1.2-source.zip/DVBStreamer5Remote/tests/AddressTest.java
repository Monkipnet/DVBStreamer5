import ru.dvbstreamer.remote.ServerAddress;
public class AddressTest {
 public static void main(String[] args) {
  String[][] good={{"192.168.1.10:9000","http://192.168.1.10:9000/"},{" https://tv.example.org/ ","https://tv.example.org/"},{"http://[2001:db8::1]:9000","http://[2001:db8::1]:9000/"},{"server.local","http://server.local/"}};
  for(String[] p:good)if(!ServerAddress.normalize(p[0]).equals(p[1]))throw new AssertionError(p[0]);
  String[] bad={"", "javascript:alert(1)","ftp://server","http://user:pass@server","http://server:70000","http://server:0","http://server/api","http://server/?token=secret","http://server/#fragment","http://two words"};
  for(String p:bad){boolean rejected=false;try{ServerAddress.normalize(p);}catch(IllegalArgumentException e){rejected=true;}if(!rejected)throw new AssertionError(p);}
  System.out.println("PASS: 14 server address cases");
 }
}
